<?php

namespace VendorDuplicator\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
