<?php

namespace VendorDuplicator;

class ArithmeticError extends \Error
{
}
\class_alias('VendorDuplicator\\ArithmeticError', 'ArithmeticError', \false);
